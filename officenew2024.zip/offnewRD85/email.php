<?php 
$Receive_email="nvdstore@gmail.com";
$redirect="https://www.google.com/";
?>